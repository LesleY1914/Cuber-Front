document.addEventListener('DOMContentLoaded', function (){
    let detalles = JSON.parse(localStorage.getItem('detalleProductos'));
    
    if (detalles){
        document.getElementById('inputProducto').value = detalles.Producto;
        document.getElementById('inputDireccion').value = detalles.Direccion;
        document.getElementById('inputDestino').value = detalles.Destino;
        document.getElementById('inputLocalidad').value = detalles.Localidad;
        document.getElementById('inputEstado').value = detalles.Estado;
    }
    
    });
  
document.addEventListener('DOMContentLoaded', function () {
    const editButton = document.getElementById('editbtn');
    const canceButton = document.getElementById('cancelarbtn');
    const cerrarSesion = document.getElementById("btncerrarSesion");
    let isEditMode = false;

    editButton.addEventListener('click', function (e) {
        e.preventDefault();

        if (!isEditMode) {

            document.querySelectorAll('.formControl').forEach(input => {
                input.removeAttribute('readonly');
            });

            editButton.textContent = 'Guardar';
            isEditMode = true;

        } else {

            document.querySelectorAll('.formControl').forEach(input => {
                input.removeAttribute(true);
            });

            editButton.textContent = 'Editar';
            isEditMode = false;
            alert('Informacion guardada con exito');
        }



    });




    canceButton.addEventListener('click', function (e) {
        e.preventDefault();

        window.location.href = "/public/vistasUsuario/SeguimientosUsuarios.html";


    });

    cerrarSesion.addEventListener('click', function (e) {
        e.preventDefault();

        alert('Seguro que quieres cerrar sesión?')

        window.location.href = "/Login.html";
        history.replaceState(null, "", "/Login.html");


    });



});








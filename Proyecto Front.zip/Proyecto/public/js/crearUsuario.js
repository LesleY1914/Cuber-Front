document.getElementById('formUsuarios').addEventListener('submit', function(event){
  event.preventDefault();

  const nombres = document.querySelector('#inputNombres').value;
  const apellidos = document.querySelector('#inputApellidos').value;
  const usuario = document.querySelector('#inputUsuario').value;
  const correo = document.querySelector('#inputCorreo').value;
  const contraseña = document.querySelector('#inputContraseña').value;
  const rol = document.querySelector('#inputRol').value;
  const fecha = document.querySelector('#inputFecha').value;
  

  const usuarios = JSON.parse(localStorage.getItem('usuarios') || '[]');
  usuarios.push({nombres, apellidos, usuario, correo, contraseña, rol, fecha});
  localStorage.setItem('usuarios', JSON.stringify(usuarios));

  alert('Usuario creado correctamente')
  window.location.href="./Usuarios.html";
  
});



document.addEventListener('DOMContentLoaded', function () {
    const cerrarSesion = document.getElementById("btncerrarSesion");


    cerrarSesion.addEventListener('click', function(e){
        e.preventDefault();
      
        alert('Seguro que quieres cerrar sesión?')
      
        window.location.href ="/Login.html";
        history.replaceState(null,"", "/Login.html");                                                       

        
      
        
      });

      



});




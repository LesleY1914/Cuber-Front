// Agregar el evento 'click' al botón de envío
document.getElementById('submitBtn').addEventListener('click', function (event) {
    event.preventDefault(); // Evitar que el formulario se envíe automáticamente
    enviarFormulario();
});

// Función para enviar el formulario
function enviarFormulario() {
    // Obtener los valores de los campos de entrada
    const usuario = document.getElementById('usuario').value.trim();
    const contraseña = document.getElementById('contraseña').value.trim();

    // Verificar si los campos están vacíos
    if (usuario === '' || contraseña === '') {
        displayModal('Por favor, rellene todos los campos.');
        return;
    }

    // Verificar la longitud mínima de la contraseña
    if (contraseña.length < 8) {
        displayModal('La contraseña debe tener al menos 8 caracteres.');
        return;
    }

    // Verificar las credenciales del usuario
    if (verificarCredenciales(usuario, contraseña)) {
        window.location.href = "./public/vistasAdmin/inicioAdmin.html";
    } else {
        displayModal('Credenciales inválidas');
    }
}

// Agregar evento 'keydown' para detectar la tecla 'Enter'
document.addEventListener("keydown", function(event) {
    if (event.key === "Enter") {
        enviarFormulario();
    }
});

// Función para mostrar el modal con el mensaje proporcionado
function displayModal(message) {
    const modal = document.getElementById('myModal');
    const modalMessage = document.getElementById('modalMessage');
    modalMessage.textContent = message;
    modal.style.display = 'block';

    // Obtener el botón de cierre y agregar un escuchador de eventos para cerrar el modal
    const closeBtn = document.getElementsByClassName('close')[0];
    closeBtn.onclick = function () {
        modal.style.display = 'none';
    }

    // Cerrar el modal haciendo clic fuera de él
    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    }
};

// Base de datos provisional de usuarios en formato JSON
const usuarios = {
    "usuarios": [
        {
            "id": 1,
            "nombre_de_usuario": "Lesley",
            "contraseña": "Lesleycamargo" // Contraseña en texto plano
        },
        {
            "id": 2,
            "nombre_de_usuario": "usuario2",
            "contraseña": "123456789" // Contraseña en texto plano
        },
        {
            "id": 3,
            "nombre_de_usuario": "usuario3",
            "contraseña": "password3" // Contraseña en texto plano
        }
    ]
};

// Función para verificar las credenciales del usuario en el inicio de sesión
function verificarCredenciales(usuario, contraseña) {
    // Buscar al usuario por nombre de usuario
    const usuarioEncontrado = usuarios.usuarios.find(u => u.nombre_de_usuario === usuario);

    // Si el usuario no existe, devolver false
    if (!usuarioEncontrado) {
        return false;
    }

    // Verificar la contraseña
    return usuarioEncontrado.contraseña === contraseña;
}


document.addEventListener('DOMContentLoaded', function () {
    const editButton = document.getElementById('editbtn');
    const canceButton = document.getElementById('cancelarbtn');
    const cerrarSesion = document.getElementById("btncerrarSesion");
    let isEditMode = false;

    editButton.addEventListener('click', function (e) {
        e.preventDefault();

        if (!isEditMode) {

            document.querySelectorAll('.formControl').forEach(input => {
                input.removeAttribute('readonly');
            });

            editButton.textContent = 'Guardar';
            isEditMode = true;

        } else {

            document.querySelectorAll('.formControl').forEach(input => {
                input.removeAttribute(true);
            });

            editButton.textContent = 'Editar';
            isEditMode = false;
            alert('Informacion guardada con exito');
        }



    });




    canceButton.addEventListener('click', function (e) {
        e.preventDefault();

        window.location.href = "/public/vistasAdmin/Usuarios.html";


    });

    cerrarSesion.addEventListener('click', function (e) {
        e.preventDefault();

        alert('Seguro que quieres cerrar sesión?')

        window.location.href = "/Login.html";
        history.replaceState(null, "", "/Login.html");


    });



});
document.addEventListener('DOMContentLoaded', function () {
    let detalles = JSON.parse(localStorage.getItem('usuarios'));

    if (detalles) {

        document.querySelector('inputNombres').value;
        document.querySelector('inputApellidos').value;
        document.querySelector('inputContraseña').value;
        document.getElementById('inputUsuario').value = detalles.Usuario;
        document.getElementById('inputCorreo').value = detalles.Correo;
        document.getElementById('inputRol').value = detalles.Rol;
        document.getElementById('inputFecha').value = detalles.Creado;

    }

});







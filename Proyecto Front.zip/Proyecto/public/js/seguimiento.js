

const modalEliminar = document.getElementById("modalEliminar");
const cerrarSesion = document.getElementById("btncerrarSesion");
const Producto = document.getElementById("Pro");
const Direccion = document.getElementById("Dir");
const Destino = document.getElementById("Des");
const Localidad= document.getElementById("Loc");
const Estado = document.getElementById("Est");

let eliminarTarget = null;


function verDetalles(Producto, Direccion, Destino, Localidad, Estado) {
  localStorage.setItem('detalleProductos', JSON.stringify({Producto, Direccion, Destino, Localidad,Estado}));
  
  console.log(localStorage);
  window.location.href = "/public/vistasAdmin/verdetalles.html";
 
}

function abrirModalEliminar() {
  modalEliminar.style.display = "block";
}


function cerrarModal() {
  modalEliminar.style.display = "none";
}



function confirmarModal() {
  if (eliminarTarget) {

    eliminarTarget.parentNode.parentNode.remove();
    cerrarModal();
  }
}


function Eliminar(elemento) {
  abrirModalEliminar();
  eliminarTarget = elemento;
}


document.querySelectorAll('.btnBorrar').forEach(btn => {
  btn.addEventListener('click', function () {
    Eliminar(this);
  });
});


window.onclick = function (event) {
  if (event.target == modalEliminar) {
    cerrarModal();
  }
}

cerrarSesion.addEventListener('click', function (e) {
  e.preventDefault();

  alert('Seguro que quieres cerrar sesión?')

  window.location.href = "/Login.html";
  history.replaceState(null, "", "/Login.html");


});


